
import java.util.Scanner;
import java.util.Arrays;

public class Programa {
    public static void main(String args[]) {

        String pelicula = "";
        String nombre = "";
        int puestos = 2;
        int edad = 0;// Lista de números enteros que supondremos
        int[] arr = new int[puestos];
        String[] persona = {}; // Lista de números enteros que supondremos
					


        Scanner read = new Scanner(System.in);
        
        for (int i=puestos; i > 1; i--) {
            System.out.println("Las peliculas disponibles son: spiderman y batman");
            System.out.println("A continuacion escriba la que deseas ver");
            pelicula = read.next();
            if(pelicula != "spiderman" || pelicula != "batman"){
                System.out.println("Muchas gracias por su eleccion");
                System.out.println("ingrese su nombre y seguido de un enter la cantidad de boletas que deseas");
                puestos = read.nextInt();
                arr[i] = puestos;
                System.out.println("ingrese su nombre y seguido de un enter la cantidad de boletas que deseas");
                nombre = read.next();
                persona[i] = nombre;

            }else {
                System.out.println("No hay peliculas con ese nombre");
            }
        }

        for(int i=0; i < arr.length; i++) {

            System.out.println("La persona "+persona[i] +" solicito " +arr[i]+ " boletas ");
        }

    }
}
