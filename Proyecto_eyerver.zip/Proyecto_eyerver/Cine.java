public class Cine {
    String pelicula = "";
    int puestos = 0;
    String hora = "";
    String duracion = "";
    int precio = 0;

    public Cine(String Vpelicula, int Vpuestos, String Vhora, String Vduracion, int Vprecio) {

        this.pelicula = Vpelicula;
        this.puestos = Vpuestos;
        this.hora = Vhora;
        this.duracion = Vduracion;
        this.precio = Vprecio;
    }

    public String getPelicula() {
        return pelicula;
    }
    public int getPuestos() {
        return puestos;
    }
    public String gethora() {
        return hora;
    }
    public String getDuracion() {
        return duracion;
    }
    public int getPrecio() {
        return precio;
    }

    public void setPelicula(String Vpelicula) {
        this.pelicula = Vpelicula;
    }
    public void setPuestos(int Vpuestos) {
        this.puestos = Vpuestos;
    }
    public void setHora(String Vhora) {
        this.hora = Vhora;
    }
    public void setDuracion(String Vduracion) {
        this.duracion = Vduracion;
    }
    public void setPrecio(int Vprecio) {
        this.precio = Vprecio;
    }


}