public class Cliente {
	String nombre = "";
	int edad = 0;

	public Cliente(String Vnombre, int Vedad) {

			this.nombre = Vnombre;
			this.edad = Vedad;
	}

	public String getNombre() {
			return nombre;
	}
	public int getEdad() {
			return edad;
	}

	public void setNombre(String Vnombre) {
			this.nombre = Vnombre;
	}
	public void setEdad(int Vedad) {
			this.edad = Vedad;
	}


}